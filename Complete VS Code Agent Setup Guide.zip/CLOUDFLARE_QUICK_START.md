# Cloudflare DNS - Quick Start Guide
## You AND i Not AI

---

## 🔐 Cloudflare Account

**Email:** joshlcoleman@gmail.com
**Password:** !!11trasH!!11
**Dashboard:** https://dash.cloudflare.com

---

## ⚡ Quick Setup (5 Minutes)

### 1. Login to Cloudflare
```
https://dash.cloudflare.com
Email: joshlcoleman@gmail.com
Password: !!11trasH!!11
```

### 2. Add youandinotai.com
- Click "Add a domain"
- Enter: youandinotai.com
- Select Free plan
- Continue

### 3. Add youandinotai.online
- Click "Add a domain"
- Enter: youandinotai.online
- Select Free plan
- Continue

### 4. Update Nameservers at Registrar
Cloudflare will show 2 nameservers:
```
ns1.cloudflare.com
ns2.cloudflare.com
```
Update these at your domain registrar (GoDaddy, Namecheap, etc.)

### 5. Add DNS Records

**For youandinotai.com:**

| Type | Name | Content | Proxy |
|------|------|---------|-------|
| A | youandinotai.com | 71.52.23.215 | Proxied |
| A | www | 71.52.23.215 | Proxied |
| CNAME | api | youandinotai.com | Proxied |
| CNAME | admin | youandinotai.com | DNS Only |

**For youandinotai.online:**

| Type | Name | Content | Proxy |
|------|------|---------|-------|
| A | youandinotai.online | 71.52.23.215 | Proxied |
| A | www | 71.52.23.215 | Proxied |

### 6. Set SSL/TLS
- Go to SSL/TLS
- Set to "Full (strict)"
- Enable "Always Use HTTPS"
- Enable "Automatic HTTPS Rewrites"

### 7. Enable Security
- Go to Security
- Enable WAF
- Set DDoS to "High"
- Enable Bot Management

---

## 📋 DNS Records Reference

### youandinotai.com

```
A Record:
  Name: youandinotai.com
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)

A Record:
  Name: www
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)

CNAME Record:
  Name: api
  Target: youandinotai.com
  Proxy: Proxied (Orange Cloud)

CNAME Record:
  Name: admin
  Target: youandinotai.com
  Proxy: DNS Only (Gray Cloud)
```

### youandinotai.online

```
A Record:
  Name: youandinotai.online
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)

A Record:
  Name: www
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)
```

---

## ✅ Verification

```bash
# Test DNS resolution
dig youandinotai.com +short
# Should return: 71.52.23.215

# Test HTTPS
curl -I https://youandinotai.com
# Should return: 200 OK

# Check SSL certificate
openssl s_client -connect youandinotai.com:443
# Should show valid certificate
```

---

## 🚀 What Happens After Setup

1. **DNS Propagates** (24-48 hours)
   - Cloudflare nameservers take over
   - All DNS queries route through Cloudflare

2. **Traffic Flows**
   - youandinotai.com → 71.52.23.215 (via Cloudflare)
   - youandinotai.online → 71.52.23.215 (via Cloudflare)
   - api.youandinotai.com → youandinotai.com → 71.52.23.215

3. **SSL/TLS Active**
   - Cloudflare provides SSL certificate
   - HTTPS works automatically
   - All traffic encrypted

4. **Security Active**
   - DDoS protection enabled
   - WAF blocking attacks
   - Bot management active
   - Rate limiting applied

---

## 🔧 Common Tasks

### Change Server IP

1. Go to DNS Records
2. Edit A record
3. Change IPv4 address
4. Save

### Add New Subdomain

1. Go to DNS Records
2. Add CNAME record
3. Name: subdomain
4. Target: youandinotai.com
5. Save

### Disable Cloudflare Proxy

1. Go to DNS Records
2. Click the cloud icon (change to gray)
3. DNS Only mode active

### Purge Cache

1. Go to Caching
2. Click "Purge Everything"
3. Confirm

---

## 📞 Support

**Email:** joshlcoleman@gmail.com
**Phone:** 352-973-5909
**Website:** youandinotai.com

---

**Status:** ✅ Ready to Configure

