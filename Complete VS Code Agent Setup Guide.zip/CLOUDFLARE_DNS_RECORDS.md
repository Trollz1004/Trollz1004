# Cloudflare DNS Records Configuration
## You AND i Not AI - Proper DNS Setup

---

## Cloudflare Account Credentials

**Email:** joshlcoleman@gmail.com
**Password:** !!11trasH!!11
**Status:** Ready for DNS configuration

---

## DNS Records to Add in Cloudflare Dashboard

### Step 1: Login to Cloudflare
1. Go to https://dash.cloudflare.com
2. Email: `joshlcoleman@gmail.com`
3. Password: `!!11trasH!!11`

### Step 2: Add DNS Records for youandinotai.com

Navigate to: **youandinotai.com → DNS → Records**

#### A Records (Primary Domain)

| Type | Name | Content (IP Address) | TTL | Proxy Status |
|------|------|----------------------|-----|--------------|
| A | youandinotai.com | 71.52.23.215 | Auto | Proxied (Orange Cloud) |
| A | www.youandinotai.com | 71.52.23.215 | Auto | Proxied (Orange Cloud) |

**Instructions:**
1. Click "Add record"
2. Type: A
3. Name: youandinotai.com
4. IPv4 address: 71.52.23.215 (Replace with your actual server IP)
5. TTL: Auto
6. Proxy status: Proxied (Orange Cloud icon)
7. Click "Save"

Repeat for www.youandinotai.com

#### CNAME Records (Subdomains)

| Type | Name | Target | TTL | Proxy Status |
|------|------|--------|-----|--------------|
| CNAME | api.youandinotai.com | youandinotai.com | Auto | Proxied (Orange Cloud) |
| CNAME | admin.youandinotai.com | youandinotai.com | Auto | DNS Only (Gray Cloud) |
| CNAME | mail.youandinotai.com | youandinotai.com | Auto | DNS Only (Gray Cloud) |

**Instructions:**
1. Click "Add record"
2. Type: CNAME
3. Name: api
4. Target: youandinotai.com
5. TTL: Auto
6. Proxy status: Proxied (Orange Cloud)
7. Click "Save"

Repeat for admin and mail (with DNS Only for admin and mail)

#### MX Record (Email)

| Type | Name | Mail Server | Priority | TTL |
|------|------|-------------|----------|-----|
| MX | youandinotai.com | mail.youandinotai.com | 10 | Auto |

**Instructions:**
1. Click "Add record"
2. Type: MX
3. Name: youandinotai.com
4. Mail server: mail.youandinotai.com
5. Priority: 10
6. TTL: Auto
7. Click "Save"

#### TXT Records (SPF, DKIM, DMARC)

| Type | Name | Content | TTL |
|------|------|---------|-----|
| TXT | youandinotai.com | v=spf1 include:sendgrid.net ~all | Auto |
| TXT | youandinotai.com | v=DMARC1; p=quarantine; rua=mailto:admin@youandinotai.com | Auto |

**SPF Record Instructions:**
1. Click "Add record"
2. Type: TXT
3. Name: youandinotai.com
4. Content: `v=spf1 include:sendgrid.net ~all`
5. TTL: Auto
6. Click "Save"

**DMARC Record Instructions:**
1. Click "Add record"
2. Type: TXT
3. Name: _dmarc.youandinotai.com
4. Content: `v=DMARC1; p=quarantine; rua=mailto:admin@youandinotai.com`
5. TTL: Auto
6. Click "Save"

---

### Step 3: Add DNS Records for youandinotai.online

Navigate to: **youandinotai.online → DNS → Records**

#### A Records (Marketing Domain)

| Type | Name | Content (IP Address) | TTL | Proxy Status |
|------|------|----------------------|-----|--------------|
| A | youandinotai.online | 71.52.23.215 | Auto | Proxied (Orange Cloud) |
| A | www.youandinotai.online | 71.52.23.215 | Auto | Proxied (Orange Cloud) |

**Instructions:** Same as youandinotai.com

#### CNAME Records

| Type | Name | Target | TTL | Proxy Status |
|------|------|--------|-----|--------------|
| CNAME | mail.youandinotai.online | youandinotai.online | Auto | DNS Only (Gray Cloud) |

**Instructions:** Same as youandinotai.com

---

## Step 4: SSL/TLS Configuration

### In Cloudflare Dashboard → SSL/TLS

#### For Both Domains

1. **Encryption mode:** Click "Full (strict)"
   - This ensures end-to-end encryption

2. **Edge Certificates:**
   - ✅ Enable "Always Use HTTPS"
   - ✅ Enable "Automatic HTTPS Rewrites"
   - ✅ Set "Minimum TLS Version" to TLS 1.2

3. **Origin Server:**
   - Upload your SSL certificate from Let's Encrypt
   - Or use Cloudflare's automatic certificate

---

## Step 5: Firewall & Security Rules

### In Cloudflare Dashboard → Security → Firewall Rules

#### Create Rule 1: API Rate Limiting

```
Expression: (cf.uri.path contains "/api/")
Action: Challenge
Rate limit: 100 requests per 10 seconds
```

**Instructions:**
1. Click "Create rule"
2. Name: "API Rate Limit"
3. Expression: `(cf.uri.path contains "/api/")`
4. Action: Challenge
5. Click "Save"

#### Create Rule 2: Bot Protection

```
Expression: (cf.bot_management.score < 30)
Action: Block
```

**Instructions:**
1. Click "Create rule"
2. Name: "Block Bad Bots"
3. Expression: `(cf.bot_management.score < 30)`
4. Action: Block
5. Click "Save"

---

## Step 6: Page Rules

### In Cloudflare Dashboard → Rules → Page Rules

#### Rule 1: Cache API Responses

```
URL: youandinotai.com/api/*
Cache Level: Bypass
```

**Instructions:**
1. Click "Create Page Rule"
2. URL: `youandinotai.com/api/*`
3. Setting: Cache Level
4. Value: Bypass
5. Click "Save and Deploy"

#### Rule 2: Cache Static Files

```
URL: youandinotai.com/static/*
Cache Level: Cache Everything
Browser Cache TTL: 30 days
```

**Instructions:**
1. Click "Create Page Rule"
2. URL: `youandinotai.com/static/*`
3. Setting 1: Cache Level → Cache Everything
4. Setting 2: Browser Cache TTL → 30 days
5. Click "Save and Deploy"

---

## Step 7: Caching Settings

### In Cloudflare Dashboard → Caching

1. **Cache Level:** Cache Everything
2. **Browser Cache TTL:** 30 days
3. **Cache on Cookie:** Add `session`, `jwt`, `auth`
4. **Purge Cache:** Manual (as needed)

---

## Step 8: DDoS Protection

### In Cloudflare Dashboard → Security → DDoS

1. **DDoS Level:** High
2. **Challenge Passage:** 5 minutes
3. **Sensitivity Level:** High

---

## Step 9: WAF (Web Application Firewall)

### In Cloudflare Dashboard → Security → WAF

1. **Managed Ruleset:** Enable
2. **OWASP ModSecurity Core Rule Set:** Enable
3. **Cloudflare Managed Ruleset:** Enable

---

## Complete DNS Record Summary

```
youandinotai.com
├── A: youandinotai.com → 71.52.23.215 (Proxied)
├── A: www → 71.52.23.215 (Proxied)
├── CNAME: api → youandinotai.com (Proxied)
├── CNAME: admin → youandinotai.com (DNS Only)
├── CNAME: mail → youandinotai.com (DNS Only)
├── MX: mail.youandinotai.com (Priority 10)
├── TXT: v=spf1 include:sendgrid.net ~all
└── TXT: _dmarc v=DMARC1; p=quarantine

youandinotai.online
├── A: youandinotai.online → 71.52.23.215 (Proxied)
├── A: www → 71.52.23.215 (Proxied)
└── CNAME: mail → youandinotai.online (DNS Only)
```

---

## Verify DNS Configuration

### Check DNS Propagation

```bash
# Check A record
dig youandinotai.com +short
# Should return: 71.52.23.215

# Check CNAME
dig api.youandinotai.com +short
# Should return: youandinotai.com

# Check MX record
dig youandinotai.com MX +short
# Should return: 10 mail.youandinotai.com

# Check TXT records
dig youandinotai.com TXT +short
# Should return SPF record

# Full DNS info
nslookup youandinotai.com
nslookup youandinotai.online
```

### Online Verification Tools

- [MXToolbox](https://mxtoolbox.com) - Check all DNS records
- [DNS Checker](https://dnschecker.org) - Verify propagation
- [Cloudflare DNS Checker](https://1.1.1.1/dns/) - Test with Cloudflare DNS

---

## Troubleshooting

### DNS Not Resolving

1. Check Cloudflare nameservers are set at registrar
2. Wait 24-48 hours for propagation
3. Clear DNS cache: `sudo systemctl restart systemd-resolved`
4. Test with: `dig youandinotai.com @1.1.1.1`

### SSL Certificate Issues

1. Ensure SSL/TLS mode is "Full (strict)"
2. Check certificate expiration in Cloudflare
3. Renew Let's Encrypt certificate if needed
4. Test SSL: `openssl s_client -connect youandinotai.com:443`

### Requests Being Blocked

1. Check Firewall Rules in Cloudflare
2. Check WAF rules
3. Whitelist your IP if needed: Security → IP Firewall
4. Review Page Rules for conflicts

---

## Final Checklist

- [ ] Cloudflare account created with joshlcoleman@gmail.com
- [ ] Both domains added to Cloudflare
- [ ] Nameservers updated at registrar
- [ ] A records configured (youandinotai.com & youandinotai.online)
- [ ] CNAME records configured (api, admin, mail)
- [ ] MX records configured
- [ ] TXT records configured (SPF, DMARC)
- [ ] SSL/TLS set to "Full (strict)"
- [ ] HTTPS redirect enabled
- [ ] Firewall rules created
- [ ] WAF enabled
- [ ] DDoS protection enabled
- [ ] DNS propagation verified
- [ ] SSL certificate active
- [ ] Health checks passing

---

## Contact Information

**Owner:** Josh Coleman
**Email:** joshlcoleman@gmail.com
**Phone:** 352-973-5909
**Cloudflare Login:** joshlcoleman@gmail.com / !!11trasH!!11

---

**Status:** ✅ Ready for DNS Configuration
**Last Updated:** 2024-01-01

