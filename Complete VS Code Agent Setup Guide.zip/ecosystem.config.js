/**
 * PM2 Ecosystem Configuration
 * You AND i Not AI - Production Dating App
 * Self-hosted on youandinotai.com
 */

module.exports = {
  apps: [
    {
      name: 'youandinotai-api',
      script: './server.js',
      instances: 'max',
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production',
        PORT: 3000
      },
      env_staging: {
        NODE_ENV: 'staging',
        PORT: 3001
      },
      // Restart policies
      max_memory_restart: '500M',
      watch: false,
      ignore_watch: ['node_modules', 'logs', '.git'],
      // Logging
      output: './logs/api-out.log',
      error: './logs/api-error.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
      // Graceful shutdown
      kill_timeout: 5000,
      wait_ready: true,
      listen_timeout: 3000,
      // Health check
      health_check: {
        endpoint: '/health',
        timeout: 5000,
        interval: 30000
      },
      // Auto restart
      autorestart: true,
      max_restarts: 10,
      min_uptime: '10s',
      // Monitoring
      monitor_env: true,
      pmx: true
    },
    {
      name: 'youandinotai-worker',
      script: './workers/background-jobs.js',
      instances: 2,
      exec_mode: 'cluster',
      env: {
        NODE_ENV: 'production'
      },
      output: './logs/worker-out.log',
      error: './logs/worker-error.log',
      max_memory_restart: '300M',
      autorestart: true
    },
    {
      name: 'youandinotai-scheduler',
      script: './workers/scheduler.js',
      instances: 1,
      exec_mode: 'fork',
      env: {
        NODE_ENV: 'production'
      },
      output: './logs/scheduler-out.log',
      error: './logs/scheduler-error.log',
      max_memory_restart: '200M',
      autorestart: true
    }
  ],

  // Deployment configuration
  deploy: {
    production: {
      user: 'ubuntu',
      host: 'youandinotai.com',
      ref: 'origin/main',
      repo: 'https://github.com/youandinotai/dating-app.git',
      path: '/var/www/youandinotai',
      'post-deploy': 'npm install && npm run db:migrate && pm2 reload ecosystem.config.js --env production',
      'pre-deploy-local': 'echo "Deploying to production"'
    },
    staging: {
      user: 'ubuntu',
      host: 'staging.youandinotai.com',
      ref: 'origin/develop',
      repo: 'https://github.com/youandinotai/dating-app.git',
      path: '/var/www/youandinotai-staging',
      'post-deploy': 'npm install && npm run db:migrate && pm2 reload ecosystem.config.js --env staging',
      'pre-deploy-local': 'echo "Deploying to staging"'
    }
  },

  // Monitoring
  monitoring: {
    enabled: true,
    pmx: true,
    profiling: true,
    network: true,
    ports: true
  }
};

