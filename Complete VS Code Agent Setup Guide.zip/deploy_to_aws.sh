#!/bin/bash

# AWS EC2 Deployment Script
# You AND i Not AI - Dating App
# Target: 3.84.226.108 (t3.micro)

AWS_IP="3.84.226.108"
AWS_USER="ubuntu"
KEY_PATH="$HOME/.ssh/dateapp.pem"
APP_DIR="/home/ubuntu/youandinotai_app"

echo "=========================================="
echo "🚀 Deploying to AWS EC2: $AWS_IP"
echo "=========================================="

# Check if key exists
if [ ! -f "$KEY_PATH" ]; then
    echo "❌ Error: dateapp.pem not found at $KEY_PATH"
    echo "Please ensure the key is in ~/.ssh/dateapp.pem"
    exit 1
fi

# Set proper permissions on key
chmod 600 "$KEY_PATH"

echo "📤 Uploading complete server.js..."
scp -i "$KEY_PATH" "$APP_DIR/server.js" "$AWS_USER@$AWS_IP:~/server.js"

echo "📤 Uploading index.html..."
scp -i "$KEY_PATH" "$APP_DIR/index.html" "$AWS_USER@$AWS_IP:~/index.html"

echo "📤 Uploading package.json..."
scp -i "$KEY_PATH" "$APP_DIR/package.json" "$AWS_USER@$AWS_IP:~/package.json"

echo "📤 Uploading .env.production..."
scp -i "$KEY_PATH" "$APP_DIR/.env.production" "$AWS_USER@$AWS_IP:~/.env.production"

echo "📤 Uploading nginx.conf..."
scp -i "$KEY_PATH" "$APP_DIR/nginx.conf" "$AWS_USER@$AWS_IP:~/nginx.conf"

echo "📤 Uploading ecosystem.config.js..."
scp -i "$KEY_PATH" "$APP_DIR/ecosystem.config.js" "$AWS_USER@$AWS_IP:~/ecosystem.config.js"

echo ""
echo "🔄 Restarting services on AWS..."
ssh -i "$KEY_PATH" "$AWS_USER@$AWS_IP" << 'REMOTE'
  echo "Setting up app directory..."
  mkdir -p ~/youandinotai_app
  mv ~/server.js ~/youandinotai_app/
  mv ~/index.html ~/youandinotai_app/
  mv ~/package.json ~/youandinotai_app/
  mv ~/.env.production ~/youandinotai_app/
  mv ~/nginx.conf ~/youandinotai_app/
  mv ~/ecosystem.config.js ~/youandinotai_app/
  
  cd ~/youandinotai_app
  
  echo "Installing dependencies..."
  npm install
  
  echo "Restarting PM2..."
  sudo pm2 restart all
  
  echo "Checking status..."
  pm2 list
  
  echo "✅ Deployment complete!"
REMOTE

echo ""
echo "=========================================="
echo "✅ DEPLOYMENT COMPLETE"
echo "=========================================="
echo "Visit: https://youandinotai.com"
echo "Direct IP: http://3.84.226.108"
echo "=========================================="
