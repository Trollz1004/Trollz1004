# YouAndINotAI Growth System - Complete Project Specification

**Last Updated:** October 25, 2025  
**Status:** Context Saved to Memory  
**Owner:** Josh Coleman (aiandyoullc@outlook.com)

---

## Project Overview

Complete automated growth system for the YouAndINotAI dating app with full production deployment to youandinotai.com and youandinotai.online domains.

### Domains
- **Primary:** youandinotai.com
- **Secondary:** youandinotai.online (redirects to primary)

---

## Technology Stack

### Frontend
- React 18.3+
- Vite 5.4+
- TailwindCSS 3.4+
- tRPC 11+ client
- @tanstack/react-query 5+
- TypeScript 5.6+

### Backend
- Node.js 20+ LTS
- Express 4.19+
- tRPC 11+ server
- TypeScript 5.6+

### Database
- PostgreSQL 16+
- Drizzle ORM 0.33+
- pg-pool for connection pooling

### External Services
- **Payments:** Stripe Checkout API
- **Email:** Resend API or SendGrid
- **Social Media:** twitter-api-v2, snoowrap
- **Scheduling:** node-cron 3.0+

### Hosting & Deployment
- Nginx reverse proxy
- PM2 process manager
- Let's Encrypt SSL/TLS
- Cloudflare DNS (optional)

---

## Project Structure

```
youandinotai_growth/
├── client/                          # React frontend
│   ├── public/
│   │   ├── logo.png
│   │   ├── og-image.png
│   │   └── favicon.ico
│   ├── src/
│   │   ├── pages/
│   │   │   └── Waitlist.tsx
│   │   ├── components/
│   │   │   ├── Hero.tsx
│   │   │   ├── WaitlistForm.tsx
│   │   │   ├── ReferralCard.tsx
│   │   │   ├── Features.tsx
│   │   │   ├── HowItWorks.tsx
│   │   │   └── Footer.tsx
│   │   ├── lib/
│   │   │   └── trpc.ts
│   │   ├── hooks/
│   │   │   └── useWaitlist.ts
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   ├── index.html
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   └── tsconfig.json
├── server/
│   ├── index.ts
│   ├── trpc.ts
│   ├── routers/
│   │   ├── waitlist.ts
│   │   └── index.ts
│   ├── automation/
│   │   ├── twitter-content.ts
│   │   ├── twitter-bot.ts
│   │   ├── tiktok-content.ts
│   │   ├── reddit-automation.ts
│   │   ├── email-campaigns.ts
│   │   ├── scheduler.ts
│   │   └── press-kit.md
│   ├── lib/
│   │   ├── db.ts
│   │   ├── stripe.ts
│   │   ├── email.ts
│   │   └── analytics.ts
│   └── types/
│       └── index.ts
├── drizzle/
│   ├── schema.ts
│   ├── migrations/
│   └── seed.ts
├── scripts/
│   ├── deploy.sh
│   ├── setup-domains.sh
│   ├── backup-db.sh
│   └── ssl-renew.sh
├── .env.local
├── .env.production
├── package.json
├── tsconfig.json
├── drizzle.config.ts
├── ecosystem.config.js
└── README.md
```

---

## Database Schema (Drizzle ORM)

### waitlistEntries
- id (primary key)
- email (unique)
- firstName
- referralCode (unique)
- referredBy
- referralCount (default: 0)
- hasSkippedLine (default: false)
- isPremium (default: false)
- stripeCustomerId
- stripeSessionId
- source ('landing', 'twitter', 'tiktok', 'reddit')
- position
- verified (default: true)
- createdAt
- updatedAt

### referrals
- id (primary key)
- referrerCode
- refereeEmail
- status ('pending', 'completed', 'expired')
- createdAt
- completedAt

### emailCampaigns
- id (primary key)
- email
- campaignType ('welcome', 'day3', 'day7', 'day14', 'day21')
- emailNumber (1-5)
- sentAt
- openedAt
- clickedAt
- createdAt

### socialPosts
- id (primary key)
- platform ('twitter', 'tiktok', 'reddit')
- postId
- content
- url
- likes
- shares
- comments
- clicks
- postedAt
- createdAt

### analyticsEvents
- id (primary key)
- eventType ('signup', 'referral', 'premium_purchase', 'email_open', etc.)
- userId/email
- metadata (JSON)
- createdAt

---

## Key Features

### Waitlist Management
- Email signup with referral code generation
- Position tracking
- Line-skipping with premium payment
- Referral reward system

### Referral System
- Unique referral codes per user
- Referral count tracking
- Referral status tracking (pending/completed/expired)
- Incentive integration with premium upgrades

### Payment Integration
- Stripe Checkout for premium access
- Webhook handling for payment verification
- Customer ID tracking

### Email Automation
- 5-email drip campaign (welcome, day 3, day 7, day 14, day 21)
- Open/click tracking
- Campaign status tracking

### Social Media Automation
- 30 Twitter posts (automated posting)
- 30 TikTok scripts (manual posting guide)
- Reddit automation
- Post performance tracking (likes, shares, comments, clicks)

### Analytics
- Event tracking (signups, referrals, purchases, email opens)
- Social media performance metrics
- Funnel analysis

---

## Nginx Configuration

### Domain Redirects
- youandinotai.online → youandinotai.com (301 redirect)
- www.youandinotai.com → youandinotai.com (301 redirect)

### API Proxying
- /api → localhost:3000
- /trpc → localhost:3000

### Frontend SPA
- try_files $uri $uri/ /index.html

### SSL/TLS
- Let's Encrypt certificates
- HTTP/2 and HTTP/3 support
- HSTS headers

---

## Cloudflare DNS Setup

1. Point youandinotai.com A record to server IP
2. Point www.youandinotai.com CNAME to youandinotai.com
3. Set youandinotai.online to redirect (301) to youandinotai.com
4. Enable SSL/TLS Full (strict) mode
5. Enable Always Use HTTPS
6. Enable HTTP/2 and HTTP/3

---

## Implementation Phases

1. **Project Scaffolding** - Initialize full-stack structure with web-db-user features
2. **Database Schema** - Implement Drizzle ORM schema and migrations
3. **Backend Procedures** - Develop tRPC procedures (waitlist, payments, webhooks)
4. **Frontend Components** - Build React/Tailwind components
5. **External Services** - Integrate Stripe, Resend/SendGrid, Twitter, Reddit APIs
6. **Automation Content** - Generate 30 tweets, 30 TikTok scripts, 5-email campaign, press kit
7. **Automation Logic** - Implement Twitter bot, TikTok scheduler, Reddit automation, email campaigns
8. **Deployment Infrastructure** - Create Nginx config, SSL setup, PM2 ecosystem, deployment scripts
9. **Testing & Documentation** - Final review and project delivery

---

## Next Steps

Awaiting user command to begin implementation.

