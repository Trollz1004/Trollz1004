# AWS EC2 Deployment Guide
## You AND i Not AI - Dating App

**Target:** AWS EC2 Instance t3.micro at **3.84.226.108**
**Domain:** youandinotai.com (via Cloudflare DNS)
**Key:** dateapp.pem at `C:\Users\uandi\Downloads\dateapp.pem`

---

## Phase 1: Upload Files to AWS

### Option A: Windows Command Prompt (Recommended)

```batch
REM Open Command Prompt and run:

cd C:\Users\uandi\Downloads

REM Upload server.js
scp -i dateapp.pem C:\path\to\server.js ubuntu@3.84.226.108:~/server.js

REM Upload all files
scp -i dateapp.pem C:\path\to\index.html ubuntu@3.84.226.108:~/index.html
scp -i dateapp.pem C:\path\to\package.json ubuntu@3.84.226.108:~/package.json
scp -i dateapp.pem C:\path\to\.env.production ubuntu@3.84.226.108:~/.env.production
scp -i dateapp.pem C:\path\to\nginx.conf ubuntu@3.84.226.108:~/nginx.conf
scp -i dateapp.pem C:\path\to\ecosystem.config.js ubuntu@3.84.226.108:~/ecosystem.config.js
```

### Option B: Linux/Mac Terminal

```bash
# Set variables
KEY_PATH="$HOME/.ssh/dateapp.pem"
AWS_IP="3.84.226.108"
APP_DIR="/path/to/youandinotai_app"

# Upload all files
scp -i "$KEY_PATH" "$APP_DIR/server.js" ubuntu@$AWS_IP:~/server.js
scp -i "$KEY_PATH" "$APP_DIR/index.html" ubuntu@$AWS_IP:~/index.html
scp -i "$KEY_PATH" "$APP_DIR/package.json" ubuntu@$AWS_IP:~/package.json
scp -i "$KEY_PATH" "$APP_DIR/.env.production" ubuntu@$AWS_IP:~/.env.production
scp -i "$KEY_PATH" "$APP_DIR/nginx.conf" ubuntu@$AWS_IP:~/nginx.conf
scp -i "$KEY_PATH" "$APP_DIR/ecosystem.config.js" ubuntu@$AWS_IP:~/ecosystem.config.js
```

---

## Phase 2: SSH into AWS and Setup

### Connect to EC2

```bash
ssh -i "%USERPROFILE%\Downloads\dateapp.pem" ubuntu@3.84.226.108
```

### Create App Directory and Move Files

```bash
# On AWS instance:
mkdir -p ~/youandinotai_app
mv ~/server.js ~/youandinotai_app/
mv ~/index.html ~/youandinotai_app/
mv ~/package.json ~/youandinotai_app/
mv ~/.env.production ~/youandinotai_app/
mv ~/nginx.conf ~/youandinotai_app/
mv ~/ecosystem.config.js ~/youandinotai_app/

cd ~/youandinotai_app
```

---

## Phase 3: Install Dependencies

### Update System

```bash
sudo apt-get update
sudo apt-get upgrade -y
```

### Install Node.js and npm

```bash
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs
node --version
npm --version
```

### Install PostgreSQL

```bash
sudo apt-get install -y postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### Install Redis

```bash
sudo apt-get install -y redis-server
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

### Install Nginx

```bash
sudo apt-get install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

### Install PM2

```bash
sudo npm install -g pm2
pm2 startup
pm2 save
```

### Install App Dependencies

```bash
cd ~/youandinotai_app
npm install
```

---

## Phase 4: Configure Environment

### Update .env.production

```bash
nano ~/youandinotai_app/.env.production
```

**Key settings to verify:**
- DATABASE_URL: PostgreSQL connection
- REDIS_URL: Redis connection
- SQUARE_ACCESS_TOKEN: Your Square token
- GEMINI_API_KEY: Your Gemini API key
- GOOGLE_CLIENT_ID: Your Google OAuth ID
- SMTP_USER: joshlcoleman@gmail.com
- ADMIN_EMAIL: admin@youandinotai.com

Press `Ctrl+X`, then `Y`, then `Enter` to save.

---

## Phase 5: Configure Nginx

### Copy Nginx Config

```bash
sudo cp ~/youandinotai_app/nginx.conf /etc/nginx/sites-available/youandinotai.com
sudo ln -s /etc/nginx/sites-available/youandinotai.com /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default
```

### Test Nginx Config

```bash
sudo nginx -t
```

### Reload Nginx

```bash
sudo systemctl reload nginx
```

---

## Phase 6: Setup SSL Certificate

### Install Certbot

```bash
sudo apt-get install -y certbot python3-certbot-nginx
```

### Generate SSL Certificate

```bash
sudo certbot certonly --standalone -d youandinotai.com -d www.youandinotai.com -d youandinotai.online
```

### Update Nginx with SSL

```bash
sudo nano /etc/nginx/sites-available/youandinotai.com
```

Add SSL paths:
```nginx
ssl_certificate /etc/letsencrypt/live/youandinotai.com/fullchain.pem;
ssl_certificate_key /etc/letsencrypt/live/youandinotai.com/privkey.pem;
```

### Reload Nginx

```bash
sudo systemctl reload nginx
```

---

## Phase 7: Start Services

### Start App with PM2

```bash
cd ~/youandinotai_app
pm2 start server.js --name "youandinotai-api"
pm2 save
```

### Check Status

```bash
pm2 list
pm2 logs youandinotai-api
```

---

## Phase 8: Verify Deployment

### Check Health Endpoint

```bash
curl http://localhost:3000/health
```

### Test HTTPS

```bash
curl -I https://youandinotai.com
```

### Check Nginx Status

```bash
sudo systemctl status nginx
```

### Check PM2 Status

```bash
pm2 status
```

---

## Phase 9: Post-Deployment

### Setup Auto-Renewal for SSL

```bash
sudo certbot renew --dry-run
```

### Monitor Logs

```bash
pm2 logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

### Restart Services (if needed)

```bash
sudo pm2 restart all
sudo systemctl restart nginx
```

---

## Troubleshooting

### App Not Running

```bash
pm2 logs youandinotai-api
pm2 restart youandinotai-api
```

### Nginx Issues

```bash
sudo nginx -t
sudo systemctl restart nginx
```

### Database Connection Failed

```bash
sudo -u postgres psql
\l  # List databases
\q  # Quit
```

### Port Already in Use

```bash
sudo lsof -i :3000
sudo kill -9 <PID>
```

---

## Final Verification

✅ SSH into 3.84.226.108
✅ All files uploaded
✅ Dependencies installed
✅ Environment configured
✅ SSL certificate active
✅ Nginx running
✅ PM2 services running
✅ youandinotai.com accessible
✅ Health endpoint responding

---

## Success Indicators

- ✅ https://youandinotai.com loads
- ✅ Dark mode UI visible
- ✅ Gemini logo displays
- ✅ Sign-in buttons work
- ✅ Pricing tiers show
- ✅ No console errors
- ✅ HTTPS working (green lock)
- ✅ API endpoints responding

---

**Status:** Ready for deployment
**Target:** youandinotai.com
**IP:** 3.84.226.108
