# Cloudflare DNS Setup Guide
## You AND i Not AI - youandinotai.com & youandinotai.online

---

## Overview

This guide configures Cloudflare DNS to route both domains to your self-hosted server with proper SSL/TLS, caching, and security.

**Primary Domain:** youandinotai.com (Main app)
**Marketing Domain:** youandinotai.online (Marketing page)
**Server IP:** 71.52.23.215 (Replace with your actual IP)

---

## Step 1: Add Domains to Cloudflare

### For youandinotai.com

1. Log in to [Cloudflare Dashboard](https://dash.cloudflare.com)
2. Click **"Add a domain"**
3. Enter: `youandinotai.com`
4. Select plan (Free or Pro)
5. Click **"Continue"**

### For youandinotai.online

1. Repeat the same process
2. Enter: `youandinotai.online`
3. Select same plan
4. Click **"Continue"**

---

## Step 2: Update Nameservers

Cloudflare will provide 2 nameservers. Update your domain registrar:

### At Your Domain Registrar (GoDaddy, Namecheap, etc.)

**For youandinotai.com:**
```
Nameserver 1: ns1.cloudflare.com
Nameserver 2: ns2.cloudflare.com
```

**For youandinotai.online:**
```
Nameserver 1: ns1.cloudflare.com
Nameserver 2: ns2.cloudflare.com
```

**Wait 24-48 hours for propagation** (Check status in Cloudflare dashboard)

---

## Step 3: Configure DNS Records

### In Cloudflare Dashboard → DNS Records

#### For youandinotai.com

| Type | Name | Content | TTL | Proxy |
|------|------|---------|-----|-------|
| A | youandinotai.com | 71.52.23.215 | Auto | Proxied (Orange Cloud) |
| A | www | 71.52.23.215 | Auto | Proxied (Orange Cloud) |
| CNAME | api | youandinotai.com | Auto | Proxied (Orange Cloud) |
| CNAME | admin | youandinotai.com | Auto | Proxied (Orange Cloud) |
| MX | @ | mail.youandinotai.com | Auto | DNS Only (Gray Cloud) |
| TXT | @ | v=spf1 include:sendgrid.net ~all | Auto | DNS Only |

#### For youandinotai.online

| Type | Name | Content | TTL | Proxy |
|------|------|---------|-----|-------|
| A | youandinotai.online | 71.52.23.215 | Auto | Proxied (Orange Cloud) |
| A | www | 71.52.23.215 | Auto | Proxied (Orange Cloud) |
| CNAME | mail | youandinotai.online | Auto | DNS Only (Gray Cloud) |

---

## Step 4: SSL/TLS Configuration

### In Cloudflare Dashboard → SSL/TLS

#### For Both Domains

1. Go to **SSL/TLS** tab
2. Set **Encryption mode** to: **"Full (strict)"**
3. Under **Edge Certificates**:
   - Enable **"Always Use HTTPS"**
   - Enable **"Automatic HTTPS Rewrites"**
   - Enable **"Minimum TLS Version"** → TLS 1.2

#### Certificate Authority Authorization (CAA)

Add CAA records for Let's Encrypt:

| Type | Name | Value |
|------|------|-------|
| CAA | youandinotai.com | 0 issue "letsencrypt.org" |
| CAA | youandinotai.online | 0 issue "letsencrypt.org" |

---

## Step 5: Caching & Performance

### In Cloudflare Dashboard → Caching

1. **Cache Level:** Set to **"Cache Everything"**
2. **Browser Cache TTL:** **30 days**
3. **Cache on Cookie:** Add `session`, `jwt`, `auth`
4. **Cache Purge:** Set to **"Purge Everything"** (manual)

### Page Rules (Optional)

1. Go to **Rules → Page Rules**
2. Add rule for API endpoints:
   ```
   youandinotai.com/api/*
   - Cache Level: Bypass
   - Security Level: High
   ```

3. Add rule for static files:
   ```
   youandinotai.com/static/*
   - Cache Level: Cache Everything
   - Browser Cache TTL: 30 days
   ```

---

## Step 6: Security Settings

### In Cloudflare Dashboard → Security

#### DDoS Protection
1. **DDoS Level:** Set to **"High"**
2. **Challenge Passage:** **5 minutes**

#### WAF (Web Application Firewall)
1. Go to **Security → WAF**
2. Enable **"Cloudflare Managed Ruleset"**
3. Enable **"OWASP ModSecurity Core Rule Set"**

#### Rate Limiting
1. Go to **Security → Rate Limiting**
2. Create rule:
   ```
   Path: /api/*
   Threshold: 100 requests per 10 seconds
   Action: Block for 1 minute
   ```

#### Bot Management
1. Go to **Security → Bots**
2. Enable **"Super Bot Fight Mode"**
3. Set **"Definitely Automated"** → Block
4. Set **"Likely Automated"** → Challenge

---

## Step 7: DNS Records - Complete Setup

### Full DNS Configuration

```
youandinotai.com
├── A Record
│   ├── youandinotai.com → 71.52.23.215 (Proxied)
│   └── www.youandinotai.com → 71.52.23.215 (Proxied)
├── CNAME Records
│   ├── api.youandinotai.com → youandinotai.com (Proxied)
│   ├── admin.youandinotai.com → youandinotai.com (Proxied)
│   └── mail.youandinotai.com → youandinotai.com (DNS Only)
├── MX Record
│   └── mail.youandinotai.com (Priority: 10)
└── TXT Records
    ├── SPF: v=spf1 include:sendgrid.net ~all
    ├── DKIM: (from SendGrid/Resend)
    └── DMARC: v=DMARC1; p=quarantine

youandinotai.online
├── A Record
│   ├── youandinotai.online → 71.52.23.215 (Proxied)
│   └── www.youandinotai.online → 71.52.23.215 (Proxied)
└── CNAME Records
    └── mail.youandinotai.online → youandinotai.online (DNS Only)
```

---

## Step 8: Verify DNS Propagation

### Check DNS Status

```bash
# Check A record
dig youandinotai.com +short

# Check CNAME records
dig api.youandinotai.com +short

# Check MX records
dig youandinotai.com MX +short

# Check TXT records
dig youandinotai.com TXT +short

# Full DNS info
nslookup youandinotai.com
nslookup youandinotai.online
```

### Online Tools
- [MXToolbox](https://mxtoolbox.com)
- [DNS Checker](https://dnschecker.org)
- [Cloudflare DNS Checker](https://1.1.1.1/dns/)

---

## Step 9: SSL Certificate Setup

### Option A: Cloudflare SSL (Recommended)

Cloudflare automatically provides SSL certificates. No additional setup needed.

### Option B: Let's Encrypt (Self-Hosted)

```bash
# Install Certbot
sudo apt-get install certbot python3-certbot-nginx

# Generate certificate
sudo certbot certonly --webroot -w /var/www/youandinotai \
  -d youandinotai.com \
  -d www.youandinotai.com \
  -d youandinotai.online \
  -d www.youandinotai.online

# Auto-renewal
sudo certbot renew --dry-run
```

---

## Step 10: Nginx Configuration with Cloudflare

### Update nginx.conf

```nginx
# Trust Cloudflare IPs
set_real_ip_from 173.245.48.0/20;
set_real_ip_from 103.21.244.0/22;
set_real_ip_from 103.22.200.0/22;
set_real_ip_from 103.31.4.0/22;
set_real_ip_from 141.101.64.0/18;
set_real_ip_from 108.162.192.0/18;
set_real_ip_from 190.93.240.0/20;
set_real_ip_from 188.114.96.0/20;
set_real_ip_from 197.234.240.0/22;
set_real_ip_from 198.41.128.0/17;
set_real_ip_from 162.158.0.0/15;
set_real_ip_from 104.16.0.0/12;
set_real_ip_from 172.64.0.0/13;
set_real_ip_from 131.0.72.0/22;

real_ip_header CF-Connecting-IP;

# HTTPS redirect
server {
    listen 80;
    server_name youandinotai.com www.youandinotai.com youandinotai.online www.youandinotai.online;
    return 301 https://$server_name$request_uri;
}

# HTTPS server
server {
    listen 443 ssl http2;
    server_name youandinotai.com www.youandinotai.com;
    
    ssl_certificate /etc/ssl/certs/youandinotai.com.crt;
    ssl_certificate_key /etc/ssl/private/youandinotai.com.key;
    
    # ... rest of config
}
```

---

## Step 11: Test Configuration

### Health Checks

```bash
# Test HTTP redirect
curl -I http://youandinotai.com

# Test HTTPS
curl -I https://youandinotai.com

# Test API endpoint
curl -I https://youandinotai.com/api/health

# Test Cloudflare headers
curl -I https://youandinotai.com | grep -i "cf-"

# Check SSL certificate
openssl s_client -connect youandinotai.com:443 -servername youandinotai.com
```

### Cloudflare Status

In Cloudflare Dashboard:
1. Go to **Overview**
2. Check **"Status"** - Should show green checkmarks
3. Verify **"Nameservers"** are active
4. Check **"SSL/TLS Status"** - Should show "Active"

---

## Step 12: Monitoring & Analytics

### In Cloudflare Dashboard → Analytics

1. **Traffic:** Monitor requests and bandwidth
2. **Security:** View blocked threats
3. **Performance:** Check cache hit ratio
4. **Errors:** Monitor 4xx/5xx errors

### Set Up Alerts

1. Go to **Notifications**
2. Create alert for:
   - High error rate (5xx)
   - DDoS attack detected
   - SSL certificate expiring
   - DNS changes

---

## Troubleshooting

### DNS Not Resolving

```bash
# Check nameserver status
whois youandinotai.com | grep -i nameserver

# Force DNS refresh
sudo systemctl restart systemd-resolved

# Check Cloudflare propagation
dig youandinotai.com @1.1.1.1
```

### SSL Certificate Issues

```bash
# Check certificate expiration
openssl x509 -in /etc/ssl/certs/youandinotai.com.crt -noout -dates

# Renew certificate
sudo certbot renew --force-renewal

# Test SSL
ssllabs.com/ssltest/analyze.html?d=youandinotai.com
```

### Slow Performance

1. Check **Caching** settings in Cloudflare
2. Verify **Cache Level** is set to "Cache Everything"
3. Check **Browser Cache TTL** is appropriate
4. Review **Page Rules** for conflicts

### Requests Being Blocked

1. Check **Security → WAF** rules
2. Review **Security → Rate Limiting** rules
3. Check **Bot Management** settings
4. Whitelist your IP if needed: **Security → IP Firewall**

---

## Security Best Practices

### 1. Enable DNSSEC

```
Cloudflare Dashboard → DNS → DNSSEC
Enable DNSSEC signing
```

### 2. Set Up Email Forwarding

```
Cloudflare Dashboard → Email Routing
Add route: admin@youandinotai.com → aiandyoullc@outlook.com
```

### 3. Restrict API Access

```
Create Firewall Rule:
- Path: /api/*
- Allow only: Your IP or VPN
```

### 4. Monitor DNS Changes

```
Enable notifications for:
- DNS record changes
- Nameserver changes
- SSL certificate expiration
```

---

## Final Verification Checklist

- [ ] Domains added to Cloudflare
- [ ] Nameservers updated at registrar
- [ ] DNS records configured (A, CNAME, MX, TXT)
- [ ] SSL/TLS set to "Full (strict)"
- [ ] HTTPS redirect enabled
- [ ] Caching configured
- [ ] WAF enabled
- [ ] DDoS protection enabled
- [ ] Rate limiting configured
- [ ] Bot management enabled
- [ ] SSL certificate active
- [ ] DNS propagation verified
- [ ] Health checks passing
- [ ] Analytics showing traffic

---

## Support

**Owner:** Josh Coleman
**Primary Email:** aiandyoullc@outlook.com
**Secondary Email:** joshlcoleman@gmail.com
**Phone:** 352-973-5909

---

**Status:** ✅ Ready for Production
**Last Updated:** 2024-01-01

