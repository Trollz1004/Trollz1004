# You AND i Not AI - AWS Deployment Guide

## Slide 1: Title Slide
**You AND i Not AI**
**AWS EC2 Deployment Guide**
Production Dating App
Target: youandinotai.com
IP: 3.84.226.108

---

## Slide 2: Deployment Overview
**What We're Deploying**
- Dark mode dating app UI
- Express.js backend with tRPC
- Square payment integration
- Google Sign-In authentication
- Gemini AI features
- PostgreSQL + Redis database
- Nginx reverse proxy
- PM2 process manager

---

## Slide 3: Architecture Diagram
**System Architecture**
```
User Browser
    ↓
Cloudflare DNS (youandinotai.com)
    ↓
Nginx Reverse Proxy (Port 443 HTTPS)
    ↓
Express.js Server (Port 3000)
    ↓
PostgreSQL Database + Redis Cache
```

---

## Slide 4: Prerequisites
**What You Need**
✅ AWS EC2 Instance (t3.micro)
✅ IP: 3.84.226.108
✅ Ubuntu 24.04 OS
✅ dateapp.pem private key
✅ Cloudflare DNS configured
✅ All app files ready
✅ Square API credentials
✅ Gemini API key

---

## Slide 5: Phase 1 - Upload Files
**Step 1: Upload to AWS**
Windows Command Prompt:
```
cd C:\Users\uandi\Downloads

scp -i dateapp.pem server.js ubuntu@3.84.226.108:~/
scp -i dateapp.pem index.html ubuntu@3.84.226.108:~/
scp -i dateapp.pem package.json ubuntu@3.84.226.108:~/
scp -i dateapp.pem .env.production ubuntu@3.84.226.108:~/
scp -i dateapp.pem nginx.conf ubuntu@3.84.226.108:~/
scp -i dateapp.pem ecosystem.config.js ubuntu@3.84.226.108:~/
```

---

## Slide 6: Phase 2 - SSH Connection
**Step 2: Connect to AWS**
```
ssh -i "%USERPROFILE%\Downloads\dateapp.pem" ubuntu@3.84.226.108
```

Create app directory:
```
mkdir -p ~/youandinotai_app
mv ~/*.js ~/youandinotai_app/
mv ~/*.html ~/youandinotai_app/
mv ~/*.json ~/youandinotai_app/
mv ~/.env.production ~/youandinotai_app/
cd ~/youandinotai_app
```

---

## Slide 7: Phase 3 - System Update
**Step 3: Update System**
```
sudo apt-get update
sudo apt-get upgrade -y
```

This ensures all system packages are current and secure.

---

## Slide 8: Phase 4 - Install Node.js
**Step 4: Install Node.js 20**
```
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

node --version
npm --version
```

Verify installation with version checks.

---

## Slide 9: Phase 5 - Install Databases
**Step 5: Install PostgreSQL & Redis**
PostgreSQL:
```
sudo apt-get install -y postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

Redis:
```
sudo apt-get install -y redis-server
sudo systemctl start redis-server
sudo systemctl enable redis-server
```

---

## Slide 10: Phase 6 - Install Web Server
**Step 6: Install Nginx**
```
sudo apt-get install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

Nginx acts as reverse proxy for your Express app.

---

## Slide 11: Phase 7 - Install PM2
**Step 7: Install Process Manager**
```
sudo npm install -g pm2
pm2 startup
pm2 save
```

PM2 keeps your app running 24/7 and auto-restarts on failure.

---

## Slide 12: Phase 8 - Install Dependencies
**Step 8: Install App Dependencies**
```
cd ~/youandinotai_app
npm install
```

This installs all Node.js packages from package.json:
- Express.js
- CORS
- Helmet
- Rate limiting
- Compression
- And more...

---

## Slide 9: Configuration
**Step 9: Configure Environment**
Edit .env.production:
```
nano ~/youandinotai_app/.env.production
```

Key settings:
- DATABASE_URL (PostgreSQL)
- REDIS_URL (Redis)
- SQUARE_ACCESS_TOKEN
- GEMINI_API_KEY
- GOOGLE_CLIENT_ID
- SMTP_USER: joshlcoleman@gmail.com
- ADMIN_EMAIL: admin@youandinotai.com

---

## Slide 10: Nginx Configuration
**Step 10: Configure Nginx**
```
sudo cp ~/youandinotai_app/nginx.conf /etc/nginx/sites-available/youandinotai.com
sudo ln -s /etc/nginx/sites-available/youandinotai.com /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

sudo nginx -t
sudo systemctl reload nginx
```

---

## Slide 11: SSL Certificate
**Step 11: Setup HTTPS with Let's Encrypt**
```
sudo apt-get install -y certbot python3-certbot-nginx

sudo certbot certonly --standalone -d youandinotai.com -d www.youandinotai.com
```

This generates free SSL certificates for HTTPS.

---

## Slide 12: Start Services
**Step 12: Start Your App**
```
cd ~/youandinotai_app
pm2 start server.js --name "youandinotai-api"
pm2 save

pm2 list
pm2 logs youandinotai-api
```

Your app is now running!

---

## Slide 13: Verification
**Step 13: Verify Deployment**
```
curl http://localhost:3000/health
curl -I https://youandinotai.com
sudo systemctl status nginx
pm2 status
```

Check that everything is running correctly.

---

## Slide 14: Access Your App
**Your App is Live!**
✅ https://youandinotai.com
✅ http://3.84.226.108
✅ https://youandinotai.online

Features:
- Dark mode UI
- Google Sign-In
- Square payments ($9.99, $19.99, $29.99)
- Gemini AI integration
- Human verification
- Real-time messaging

---

## Slide 15: Troubleshooting
**Common Issues & Solutions**

App not running:
```
pm2 logs youandinotai-api
pm2 restart youandinotai-api
```

Nginx issues:
```
sudo nginx -t
sudo systemctl restart nginx
```

Port in use:
```
sudo lsof -i :3000
sudo kill -9 <PID>
```

---

## Slide 16: Monitoring
**Keep Your App Healthy**
Monitor logs:
```
pm2 logs
tail -f /var/log/nginx/access.log
tail -f /var/log/nginx/error.log
```

Restart services:
```
sudo pm2 restart all
sudo systemctl restart nginx
```

---

## Slide 17: Success Checklist
**Deployment Complete When:**
✅ SSH connection successful
✅ All files uploaded
✅ Dependencies installed
✅ Environment configured
✅ SSL certificate active
✅ Nginx running
✅ PM2 services running
✅ youandinotai.com loads
✅ Dark mode UI visible
✅ Sign-in buttons work
✅ Pricing tiers display
✅ HTTPS working (green lock)
✅ API endpoints responding

---

## Slide 18: Next Steps
**After Deployment**
1. Test all features thoroughly
2. Monitor logs for errors
3. Set up SSL auto-renewal
4. Configure email notifications
5. Set up database backups
6. Monitor performance metrics
7. Plan scaling strategy

---

## Slide 19: Support & Resources
**Contact Information**
Email: joshlcoleman@gmail.com
Admin: admin@youandinotai.com

Resources:
- AWS EC2 Documentation
- Express.js Guide
- Nginx Configuration
- PM2 Documentation
- Let's Encrypt Support

---

## Slide 20: Summary
**You AND i Not AI - Deployed!**
✅ Production-ready dating app
✅ Secure HTTPS connection
✅ Scalable architecture
✅ 24/7 uptime with PM2
✅ Global CDN via Cloudflare
✅ Professional branding
✅ Anti-bot design theme
✅ Gemini AI integration

Ready for users!

