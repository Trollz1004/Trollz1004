# You AND i Not AI - Production Dating App

**The dating app with verified humans only. Gemini-powered icebreakers. Real connections, zero AI catfishing.**

![Status](https://img.shields.io/badge/Status-Production%20Ready-brightgreen)
![License](https://img.shields.io/badge/License-MIT-blue)
![Version](https://img.shields.io/badge/Version-1.0.0-blue)

## Features

✅ **Dark Mode UI** - Premium, modern interface with Gemini branding
✅ **Google Sign-In** - Seamless authentication with Google OAuth
✅ **Square Payments** - 3 pricing tiers ($9.99, $19.99, $29.99)
✅ **Human Verification** - Liveness check, ID verification, facial recognition
✅ **Gemini AI** - Smart icebreakers, jokes, compatibility analysis
✅ **Real-Time Messaging** - WebSocket-based instant messaging
✅ **Profile Swiping** - Tinder-like matching interface
✅ **Anti-Bot Design** - 100% human-verified community
✅ **Self-Hosted** - Complete control on youandinotai.com
✅ **Production Grade** - Enterprise-level security & performance

## Tech Stack

### Frontend
- HTML5 / CSS3 / JavaScript
- Dark mode with Gemini colors
- Responsive design
- Google Sign-In SDK
- Square Web Payments SDK

### Backend
- Node.js 20+
- Express.js
- PostgreSQL
- Redis
- Socket.io (real-time messaging)

### AI & Integrations
- Google Gemini API
- Square Payment API
- Google OAuth
- Twilio (SMS verification)

### Deployment
- Nginx (reverse proxy)
- PM2 (process manager)
- Docker & Docker Compose
- SSL/TLS (Let's Encrypt)

## Quick Start

```bash
# 1. Clone repository
git clone https://github.com/youandinotai/dating-app.git
cd dating-app

# 2. Install dependencies
npm install

# 3. Setup environment
cp .env.production .env
nano .env  # Edit with your credentials

# 4. Start application
npm start

# 5. Open browser
open https://youandinotai.com
```

## Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f api

# Stop containers
docker-compose down
```

## Environment Variables

```bash
# Square Payment
SQUARE_ACCESS_TOKEN=your_token
SQUARE_APP_ID=your_app_id
SQUARE_LOCATION_ID=your_location_id

# Google OAuth
GOOGLE_CLIENT_ID=your_client_id
GOOGLE_CLIENT_SECRET=your_secret

# Gemini AI
GEMINI_API_KEY=your_api_key

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/youandinotai

# Email
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Domains
DOMAIN_MAIN=youandinotai.com
DOMAIN_MARKETING=youandinotai.online
```

## API Endpoints

### Authentication
- `POST /api/auth/signup` - Create account
- `POST /api/auth/login` - Sign in
- `POST /api/auth/google` - Google OAuth

### Payments
- `POST /api/payment/process` - Process payment
- `POST /api/payment/webhook` - Square webhook

### Gemini AI
- `POST /api/gemini/icebreaker` - Generate icebreaker
- `POST /api/gemini/joke` - Generate joke
- `POST /api/gemini/compatibility` - Analyze compatibility

### Verification
- `POST /api/verification/liveness` - Liveness check
- `POST /api/verification/id` - ID verification

### Matching
- `GET /api/matches` - Get matches
- `POST /api/matches/like` - Like user

### Messaging
- `GET /api/messages/:conversationId` - Get messages
- `POST /api/messages/send` - Send message

## Pricing Tiers

| Plan | Price | Features |
|------|-------|----------|
| **Starter** | $9.99/mo | Unlimited swipes, 5 super likes/day, basic messaging |
| **Pro** | $19.99/mo | Unlimited super likes, priority messaging, profile boost 2x/week |
| **Premium** | $29.99/mo | Everything in Pro + VIP support, AI assistant, exclusive events |

## Security

- 🔐 HTTPS/TLS encryption
- 🛡️ CORS protection
- 🔑 JWT authentication
- 🚫 Rate limiting
- ✅ Human verification
- 🔍 ID verification
- 👁️ Liveness detection
- 🚨 Anti-bot protocols

## Performance

- ⚡ Nginx reverse proxy
- 💾 Redis caching
- 📊 Database indexing
- 🔄 Load balancing
- 📦 Gzip compression
- 🎯 CDN-ready

## Monitoring

```bash
# PM2 monitoring
pm2 monit

# View logs
pm2 logs youandinotai-api

# Web dashboard
pm2 web  # http://localhost:9615
```

## Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) for comprehensive deployment guide.

### Quick Deploy

```bash
# PM2
npm run pm2:start

# Docker
docker-compose up -d

# Manual
npm start
```

## File Structure

```
youandinotai_app/
├── index.html              # Main frontend
├── server.js               # Express backend
├── package.json            # Dependencies
├── .env.production         # Production config
├── nginx.conf              # Nginx configuration
├── ecosystem.config.js     # PM2 configuration
├── docker-compose.yml      # Docker Compose
├── Dockerfile              # Docker image
├── DEPLOYMENT.md           # Deployment guide
├── README.md               # This file
└── logo.png                # Gemini-branded logo
```

## Development

```bash
# Install dev dependencies
npm install --save-dev

# Run in development
npm run dev

# Run tests
npm test

# Lint code
npm run lint

# Format code
npm run format
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License - See LICENSE file for details

## Support

- **Owner**: Josh Coleman
- **Primary Email**: aiandyoullc@outlook.com
- **Secondary Email**: joshlcoleman@gmail.com
- **Phone**: 352-973-5909
- **Website**: https://youandinotai.com
- **Marketing**: https://youandinotai.online

## Roadmap

- [ ] Video call integration
- [ ] Voice messaging
- [ ] Advanced matching algorithm
- [ ] Events & group dating
- [ ] Premium filters
- [ ] Verified badge system
- [ ] Mobile app (iOS/Android)
- [ ] International expansion

## Status

✅ **Production Ready**
- All features implemented
- Security hardened
- Performance optimized
- Fully tested
- Ready for deployment

---

**Made with ❤️ by Josh Coleman**

*Real connections. Verified humans. Zero AI catfishing.*

