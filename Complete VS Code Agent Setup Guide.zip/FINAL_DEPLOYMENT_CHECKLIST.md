# Final Deployment Checklist
## You AND i Not AI - Production Dating App

---

## 🎯 Project Information

| Item | Value |
|------|-------|
| **App Name** | You AND i Not AI |
| **Primary Domain** | youandinotai.com |
| **Marketing Domain** | youandinotai.online |
| **Server IP** | 71.52.23.215 |
| **Owner** | Josh Coleman |
| **Main Email** | joshlcoleman@gmail.com |
| **App Admin Email** | admin@youandinotai.com |
| **Phone** | 352-973-5909 |

---

## 🔐 Cloudflare Configuration

### Account Details
- **Email:** joshlcoleman@gmail.com
- **Password:** !!11trasH!!11
- **Dashboard:** https://dash.cloudflare.com

### DNS Records to Add

#### youandinotai.com
```
A Record:
  Name: youandinotai.com
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)

A Record:
  Name: www
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)

CNAME Record:
  Name: api
  Target: youandinotai.com
  Proxy: Proxied (Orange Cloud)

CNAME Record:
  Name: admin
  Target: youandinotai.com
  Proxy: DNS Only (Gray Cloud)
```

#### youandinotai.online
```
A Record:
  Name: youandinotai.online
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)

A Record:
  Name: www
  IPv4: 71.52.23.215
  Proxy: Proxied (Orange Cloud)
```

### SSL/TLS Settings
- [ ] Encryption mode: "Full (strict)"
- [ ] Always Use HTTPS: Enabled
- [ ] Automatic HTTPS Rewrites: Enabled
- [ ] Minimum TLS Version: TLS 1.2

### Security Settings
- [ ] WAF: Enabled
- [ ] DDoS Level: High
- [ ] Bot Management: Enabled
- [ ] Rate Limiting: 100 req/10 sec for /api/*

---

## 📧 Email Configuration

### SMTP Settings
| Setting | Value |
|---------|-------|
| SMTP Host | smtp.gmail.com |
| SMTP Port | 587 |
| SMTP User | joshlcoleman@gmail.com |
| SMTP Password | [Your Gmail app password] |
| From Address | noreply@youandinotai.com |
| From Name | You AND i Not AI |

### Email Addresses
| Purpose | Email |
|---------|-------|
| Owner | joshlcoleman@gmail.com |
| Admin | admin@youandinotai.com |
| Support | admin@youandinotai.com |

---

## 💳 Payment Integration

### Square Credentials
- [ ] SQUARE_ACCESS_TOKEN: `EAAAl8YxbB79dPEKpMpdqT_3d1CkxrhH6SvqDf0hfN7EH34NXHyXqQo8IwHOk5Gh`
- [ ] SQUARE_APP_ID: `sq0idp-O4K4lNKXVSQoWdfgczv17Q`
- [ ] SQUARE_LOCATION_ID: [Update with your location ID]
- [ ] SQUARE_WEBHOOK_SECRET: [Update with your webhook secret]

### Pricing Tiers
| Plan | Price | Square Product ID |
|------|-------|-------------------|
| Starter | $9.99/mo | [Update] |
| Pro | $19.99/mo | [Update] |
| Premium | $29.99/mo | [Update] |

---

## 🤖 AI Integration

### Gemini API
- [ ] GEMINI_API_KEY: `AIzaSyBuaA6sdJ2kvIeXiL1jY4Qm7StBuaA6sdJ2kvIeXiL1jY4Qm7StAUwFWG4`
- [ ] GEMINI_MODEL: `gemini-2.5-flash`
- [ ] Features Enabled:
  - [ ] Icebreaker generation
  - [ ] Joke generation
  - [ ] Compatibility analysis

### Google OAuth
- [ ] GOOGLE_CLIENT_ID: [Update with your client ID]
- [ ] GOOGLE_CLIENT_SECRET: [Update with your secret]
- [ ] GOOGLE_CALLBACK_URL: `https://youandinotai.com/auth/google/callback`

---

## 🗄️ Database Configuration

### PostgreSQL
- [ ] DATABASE_URL: `postgresql://postgres:password@localhost:5432/youandinotai`
- [ ] DB_PASSWORD: [Update with secure password]
- [ ] Database created: youandinotai
- [ ] Migrations run: `npm run db:migrate`

### Redis
- [ ] REDIS_URL: `redis://localhost:6379`
- [ ] Cache TTL: 3600 seconds
- [ ] Session TTL: 86400 seconds

---

## 🔑 Security Configuration

### JWT & Sessions
- [ ] JWT_SECRET: [Generate 32+ character secret]
- [ ] SESSION_SECRET: [Generate 32+ character secret]
- [ ] MAX_LOGIN_ATTEMPTS: 5
- [ ] LOGIN_LOCKOUT_TIME: 15 minutes

### CORS
- [ ] CORS_ORIGINS: `https://youandinotai.com,https://youandinotai.online,https://admin.youandinotai.com`
- [ ] Rate Limiting: 100 requests per 15 minutes
- [ ] API Rate Limit: 100 requests per 15 minutes

### Verification
- [ ] VERIFICATION_REQUIRED: true
- [ ] LIVENESS_CHECK: true
- [ ] ID_VERIFICATION: true
- [ ] FACIAL_RECOGNITION: true

---

## 📁 File Structure Verification

```
youandinotai_app/
├── ✅ index.html                          (Dark mode UI)
├── ✅ server.js                           (Express backend)
├── ✅ package.json                        (Dependencies)
├── ✅ .env.production                     (Configuration)
├── ✅ nginx.conf                          (Reverse proxy)
├── ✅ ecosystem.config.js                 (PM2 config)
├── ✅ docker-compose.yml                  (Docker stack)
├── ✅ Dockerfile                          (Container image)
├── ✅ DEPLOYMENT.md                       (Setup guide)
├── ✅ README.md                           (Documentation)
├── ✅ CLOUDFLARE_DNS_SETUP.md            (DNS guide)
├── ✅ CLOUDFLARE_DNS_RECORDS.md          (DNS records)
├── ✅ CLOUDFLARE_QUICK_START.md          (Quick start)
├── ✅ FINAL_DEPLOYMENT_CHECKLIST.md      (This file)
├── ✅ logo.png                            (Gemini logo)
└── ✅ .gitignore                          (Git config)
```

---

## 🚀 Deployment Steps

### Step 1: Cloudflare DNS Setup
- [ ] Login to Cloudflare (joshlcoleman@gmail.com / !!11trasH!!11)
- [ ] Add youandinotai.com domain
- [ ] Add youandinotai.online domain
- [ ] Update nameservers at registrar
- [ ] Add A records pointing to 71.52.23.215
- [ ] Add CNAME records
- [ ] Set SSL/TLS to "Full (strict)"
- [ ] Enable security features
- [ ] Wait for DNS propagation (24-48 hours)

### Step 2: Server Setup
- [ ] SSH into server: `ssh ubuntu@71.52.23.215`
- [ ] Install Node.js 20+
- [ ] Install PostgreSQL
- [ ] Install Redis
- [ ] Install Nginx
- [ ] Clone repository
- [ ] Copy .env.production and update credentials
- [ ] Run `npm install`
- [ ] Run `npm run db:migrate`

### Step 3: SSL Certificate
- [ ] Install Certbot: `sudo apt-get install certbot`
- [ ] Generate certificate: `sudo certbot certonly --webroot -w /var/www/youandinotai -d youandinotai.com -d youandinotai.online`
- [ ] Update nginx.conf with certificate paths
- [ ] Test SSL: `sudo nginx -t`

### Step 4: Start Services
- [ ] Start PostgreSQL: `sudo systemctl start postgresql`
- [ ] Start Redis: `sudo systemctl start redis-server`
- [ ] Start Nginx: `sudo systemctl start nginx`
- [ ] Start app with PM2: `npm run pm2:start`
- [ ] Verify: `pm2 list`

### Step 5: Verification
- [ ] Test HTTP redirect: `curl -I http://youandinotai.com`
- [ ] Test HTTPS: `curl -I https://youandinotai.com`
- [ ] Test API: `curl -I https://youandinotai.com/api/health`
- [ ] Check logs: `pm2 logs youandinotai-api`
- [ ] Monitor: `pm2 monit`

---

## 📊 Monitoring & Maintenance

### Daily Checks
- [ ] Check PM2 status: `pm2 list`
- [ ] Check logs: `pm2 logs`
- [ ] Check disk space: `df -h`
- [ ] Check memory: `free -h`

### Weekly Checks
- [ ] Review error logs
- [ ] Check Cloudflare analytics
- [ ] Verify SSL certificate expiration
- [ ] Test backup procedures

### Monthly Checks
- [ ] Database optimization
- [ ] Security updates
- [ ] Performance analysis
- [ ] Backup verification

### Backup Strategy
- [ ] Database backup: Daily
- [ ] Application backup: Weekly
- [ ] Retention: 30 days
- [ ] Test restore: Monthly

---

## 🔒 Security Checklist

### Access Control
- [ ] SSH key-based authentication only
- [ ] Firewall rules configured
- [ ] Admin panel restricted to specific IPs
- [ ] Rate limiting enabled

### Data Protection
- [ ] HTTPS/TLS enforced
- [ ] Database passwords secured
- [ ] API keys in .env (not in code)
- [ ] Sensitive data encrypted

### Monitoring
- [ ] Error logging enabled
- [ ] Access logging enabled
- [ ] Security alerts configured
- [ ] Intrusion detection active

### Compliance
- [ ] Privacy policy published
- [ ] Terms of service published
- [ ] GDPR compliance verified
- [ ] Data retention policy defined

---

## 📞 Support & Escalation

### Contact Information
- **Owner:** Josh Coleman
- **Email:** joshlcoleman@gmail.com
- **Phone:** 352-973-5909
- **Website:** youandinotai.com

### Emergency Contacts
- **App Down:** Check PM2 status, restart services
- **Database Issues:** Check PostgreSQL logs
- **SSL Issues:** Check certificate expiration, renew if needed
- **DNS Issues:** Check Cloudflare dashboard

---

## ✅ Final Verification

- [ ] All files created and verified
- [ ] Cloudflare account configured
- [ ] DNS records added and propagated
- [ ] SSL certificate installed
- [ ] Environment variables set
- [ ] Database migrations completed
- [ ] Services running (PostgreSQL, Redis, Nginx, Node.js)
- [ ] Health checks passing
- [ ] HTTPS working
- [ ] API endpoints responding
- [ ] Admin panel accessible
- [ ] Monitoring active
- [ ] Backups configured

---

## 🎉 Deployment Complete

When all items are checked:

1. **App is live** at https://youandinotai.com
2. **Marketing page** at https://youandinotai.online
3. **Admin panel** at https://admin.youandinotai.com
4. **API** at https://youandinotai.com/api
5. **Monitoring** via PM2 and Cloudflare

---

**Status:** ✅ **READY FOR DEPLOYMENT**

**Last Updated:** 2024-01-01
**Deployed By:** Josh Coleman
**Deployment Date:** [To be filled]

