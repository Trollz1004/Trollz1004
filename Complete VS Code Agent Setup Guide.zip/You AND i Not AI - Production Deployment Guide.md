# You AND i Not AI - Production Deployment Guide

## Overview

This is a **production-grade dating app** with:
- ✅ Dark mode UI with Gemini branding
- ✅ Google Sign-In authentication
- ✅ Square payment integration (3 tiers: $9.99, $19.99, $29.99)
- ✅ Human verification protocols (liveness check, ID verification)
- ✅ Gemini AI integration (icebreakers, jokes, compatibility)
- ✅ Self-hosted on youandinotai.com and youandinotai.online
- ✅ 100% production-ready code

---

## Quick Start

### 1. Prerequisites

```bash
# Node.js 20+
node --version

# npm 10+
npm --version

# Docker & Docker Compose (optional)
docker --version
docker-compose --version
```

### 2. Environment Setup

```bash
# Copy production environment file
cp .env.production .env

# Update with your actual credentials
nano .env
```

**Required Environment Variables:**
- `SQUARE_ACCESS_TOKEN` - Square payment token
- `SQUARE_APP_ID` - Square app ID
- `GEMINI_API_KEY` - Google Gemini API key
- `GOOGLE_CLIENT_ID` - Google OAuth client ID
- `GOOGLE_CLIENT_SECRET` - Google OAuth secret
- `DATABASE_URL` - PostgreSQL connection string
- `SMTP_USER` / `SMTP_PASS` - Email credentials

### 3. Install Dependencies

```bash
npm install
```

### 4. Database Setup

```bash
# Run migrations
npm run db:migrate

# Generate schema
npm run db:generate

# Push to database
npm run db:push
```

### 5. Generate SSL Certificates

```bash
# Self-signed (development)
npm run ssl:generate

# Production (Let's Encrypt)
sudo certbot certonly --standalone -d youandinotai.com -d youandinotai.online
```

### 6. Start Application

#### Option A: Direct Node.js

```bash
npm start
```

#### Option B: PM2 (Recommended)

```bash
npm run pm2:start
npm run pm2:logs
```

#### Option C: Docker Compose

```bash
docker-compose up -d
docker-compose logs -f api
```

---

## Production Deployment

### On Ubuntu Server

```bash
# 1. SSH into server
ssh ubuntu@youandinotai.com

# 2. Clone repository
git clone https://github.com/youandinotai/dating-app.git
cd dating-app

# 3. Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 4. Install PM2 globally
sudo npm install -g pm2

# 5. Setup environment
cp .env.production .env
nano .env  # Edit with your credentials

# 6. Install dependencies
npm install --production

# 7. Setup database
npm run db:migrate

# 8. Start with PM2
npm run pm2:start

# 9. Save PM2 startup
pm2 startup
pm2 save

# 10. Setup Nginx
sudo cp nginx.conf /etc/nginx/sites-available/youandinotai
sudo ln -s /etc/nginx/sites-available/youandinotai /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

### With Docker

```bash
# 1. Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# 2. Clone and setup
git clone https://github.com/youandinotai/dating-app.git
cd dating-app

# 3. Create .env file
cp .env.production .env
nano .env

# 4. Start containers
docker-compose up -d

# 5. View logs
docker-compose logs -f api
```

---

## Configuration

### Nginx Setup

```bash
# Copy Nginx config
sudo cp nginx.conf /etc/nginx/nginx.conf

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### SSL Certificates

```bash
# Let's Encrypt (Recommended)
sudo certbot certonly --webroot -w /var/www/youandinotai \
  -d youandinotai.com \
  -d www.youandinotai.com \
  -d youandinotai.online

# Auto-renewal
sudo certbot renew --dry-run
```

### Database

```bash
# PostgreSQL connection
psql postgresql://postgres:password@localhost:5432/youandinotai

# Run migrations
npm run db:migrate

# Check schema
npm run db:generate
```

---

## API Endpoints

### Authentication
- `POST /api/auth/signup` - Create account
- `POST /api/auth/login` - Sign in
- `POST /api/auth/google` - Google OAuth

### Payments (Square)
- `POST /api/payment/process` - Process payment
- `POST /api/payment/webhook` - Square webhook

### Gemini AI
- `POST /api/gemini/icebreaker` - Generate icebreaker
- `POST /api/gemini/joke` - Generate joke
- `POST /api/gemini/compatibility` - Analyze compatibility

### Verification
- `POST /api/verification/liveness` - Liveness check
- `POST /api/verification/id` - ID verification

### Users
- `GET /api/users/:userId` - Get profile
- `PUT /api/users/:userId` - Update profile

### Matching
- `GET /api/matches` - Get matches
- `POST /api/matches/like` - Like user

### Messaging
- `GET /api/messages/:conversationId` - Get messages
- `POST /api/messages/send` - Send message

---

## Monitoring

### PM2 Monitoring

```bash
# View processes
pm2 list

# View logs
pm2 logs youandinotai-api

# Monitor in real-time
pm2 monit

# View metrics
pm2 web  # http://localhost:9615
```

### System Monitoring

```bash
# CPU & Memory
top

# Disk usage
df -h

# Network
netstat -tulpn | grep LISTEN

# Nginx logs
tail -f /var/log/nginx/youandinotai.access.log
tail -f /var/log/nginx/youandinotai.error.log
```

---

## Scaling

### Horizontal Scaling

```bash
# Multiple PM2 instances
pm2 start ecosystem.config.js -i max

# Load balancing with Nginx (already configured)
```

### Database Optimization

```bash
# Create indexes
psql -U postgres -d youandinotai -c "
  CREATE INDEX idx_users_email ON users(email);
  CREATE INDEX idx_matches_user_id ON matches(user_id);
"

# Backup database
pg_dump postgresql://postgres:password@localhost:5432/youandinotai > backup.sql

# Restore database
psql postgresql://postgres:password@localhost:5432/youandinotai < backup.sql
```

---

## Troubleshooting

### Application won't start

```bash
# Check logs
npm run pm2:logs

# Check port availability
lsof -i :3000

# Check environment variables
cat .env | grep -E "SQUARE|GEMINI|DATABASE"
```

### Database connection error

```bash
# Test connection
psql postgresql://postgres:password@localhost:5432/youandinotai

# Check PostgreSQL service
sudo systemctl status postgresql

# Restart PostgreSQL
sudo systemctl restart postgresql
```

### SSL certificate issues

```bash
# Check certificate
openssl x509 -in /etc/ssl/certs/youandinotai.com.crt -text -noout

# Renew certificate
sudo certbot renew --force-renewal

# Check Nginx SSL
sudo nginx -t
```

### Payment processing fails

```bash
# Verify Square credentials
echo $SQUARE_ACCESS_TOKEN
echo $SQUARE_APP_ID

# Test Square API
curl -X GET https://connect.squareup.com/v2/locations \
  -H "Authorization: Bearer $SQUARE_ACCESS_TOKEN"
```

---

## Security Best Practices

### 1. Firewall Configuration

```bash
# UFW (Uncomplicated Firewall)
sudo ufw allow 22/tcp
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw enable
```

### 2. SSL/TLS

```bash
# Force HTTPS
# Already configured in nginx.conf
```

### 3. Environment Variables

```bash
# Never commit .env file
echo ".env" >> .gitignore

# Use strong secrets
openssl rand -base64 32  # Generate strong secret
```

### 4. Database Security

```bash
# Change default PostgreSQL password
sudo -u postgres psql
ALTER USER postgres WITH PASSWORD 'strong_password';

# Restrict database access
# Edit /etc/postgresql/*/main/pg_hba.conf
```

### 5. Rate Limiting

```bash
# Already configured in nginx.conf and Express
# Adjust limits in .env if needed
```

---

## Backup & Recovery

### Automated Backups

```bash
# Create backup script
cat > /home/ubuntu/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/backups/youandinotai"
DATE=$(date +%Y%m%d_%H%M%S)

# Database backup
pg_dump postgresql://postgres:password@localhost:5432/youandinotai | \
  gzip > $BACKUP_DIR/db_$DATE.sql.gz

# Application backup
tar -czf $BACKUP_DIR/app_$DATE.tar.gz /var/www/youandinotai

# Keep only last 7 days
find $BACKUP_DIR -name "*.gz" -mtime +7 -delete
EOF

chmod +x /home/ubuntu/backup.sh

# Schedule daily backup
crontab -e
# Add: 0 2 * * * /home/ubuntu/backup.sh
```

### Restore from Backup

```bash
# Restore database
gunzip -c /backups/youandinotai/db_20240101_020000.sql.gz | \
  psql postgresql://postgres:password@localhost:5432/youandinotai

# Restore application
tar -xzf /backups/youandinotai/app_20240101_020000.tar.gz -C /
```

---

## Performance Optimization

### Caching

```bash
# Redis is already configured
# Cache TTL: 3600 seconds (1 hour)
# Session TTL: 86400 seconds (24 hours)
```

### Database Optimization

```bash
# Enable query logging
psql -U postgres -d youandinotai -c "
  ALTER SYSTEM SET log_statement = 'all';
  SELECT pg_reload_conf();
"

# Analyze query performance
EXPLAIN ANALYZE SELECT * FROM users WHERE email = 'user@example.com';
```

### CDN Integration

```bash
# Serve static files from CDN
# Update index.html to use CDN URLs for images/assets
```

---

## Support & Contact

- **Owner**: Josh Coleman
- **Primary Email**: aiandyoullc@outlook.com
- **Secondary Email**: joshlcoleman@gmail.com
- **Phone**: 352-973-5909
- **Domain**: youandinotai.com
- **Marketing**: youandinotai.online

---

## Version History

- **v1.0.0** (2024) - Initial production release
  - Dark mode UI with Gemini branding
  - Google Sign-In & Square payments
  - Human verification protocols
  - Gemini AI integration
  - Self-hosted on youandinotai.com

---

**Last Updated**: 2024-01-01
**Status**: Production Ready ✅

